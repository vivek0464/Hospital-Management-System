﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form2
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.StaffPanel = New System.Windows.Forms.Panel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.LogoutBtn = New System.Windows.Forms.Button()
        Me.EditProfileBtn = New System.Windows.Forms.Button()
        Me.PersonalInfoPanel2 = New System.Windows.Forms.Panel()
        Me.PersonalInfoPanel1 = New System.Windows.Forms.Panel()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.AvailabilityBtn = New System.Windows.Forms.Button()
        Me.StaffPanel2 = New System.Windows.Forms.Panel()
        Me.StaffPanel1 = New System.Windows.Forms.Panel()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CheckUpBtn = New System.Windows.Forms.Button()
        Me.UpdateDetailsBtn = New System.Windows.Forms.Button()
        Me.AdmitBtn = New System.Windows.Forms.Button()
        Me.RegistrationBtn = New System.Windows.Forms.Button()
        Me.PatientPanel2 = New System.Windows.Forms.Panel()
        Me.PatientPanel1 = New System.Windows.Forms.Panel()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.BloodAvailabilityBtn = New System.Windows.Forms.Button()
        Me.RegisterRecieverBtn = New System.Windows.Forms.Button()
        Me.RegisterDonorBtn = New System.Windows.Forms.Button()
        Me.BloodBankPanel2 = New System.Windows.Forms.Panel()
        Me.BloodBankPanel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 36.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.White
        Me.Label1.Location = New System.Drawing.Point(428, 35)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(845, 69)
        Me.Label1.TabIndex = 2
        Me.Label1.Text = "Golisano's Hospital Of Florida"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'StaffPanel
        '
        Me.StaffPanel.AutoScroll = True
        Me.StaffPanel.BackColor = System.Drawing.Color.White
        Me.StaffPanel.Location = New System.Drawing.Point(716, 141)
        Me.StaffPanel.Name = "StaffPanel"
        Me.StaffPanel.Size = New System.Drawing.Size(977, 825)
        Me.StaffPanel.TabIndex = 3
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.GroupBox5)
        Me.Panel1.Controls.Add(Me.GroupBox3)
        Me.Panel1.Controls.Add(Me.GroupBox2)
        Me.Panel1.Controls.Add(Me.GroupBox4)
        Me.Panel1.Location = New System.Drawing.Point(126, 141)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(380, 825)
        Me.Panel1.TabIndex = 6
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.LogoutBtn)
        Me.GroupBox5.Controls.Add(Me.EditProfileBtn)
        Me.GroupBox5.Controls.Add(Me.PersonalInfoPanel2)
        Me.GroupBox5.Controls.Add(Me.PersonalInfoPanel1)
        Me.GroupBox5.Font = New System.Drawing.Font("MS Reference Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(13, 647)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(351, 173)
        Me.GroupBox5.TabIndex = 12
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Personal Info"
        '
        'LogoutBtn
        '
        Me.LogoutBtn.FlatAppearance.BorderSize = 0
        Me.LogoutBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.LogoutBtn.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LogoutBtn.Location = New System.Drawing.Point(20, 102)
        Me.LogoutBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.LogoutBtn.Name = "LogoutBtn"
        Me.LogoutBtn.Size = New System.Drawing.Size(311, 50)
        Me.LogoutBtn.TabIndex = 6
        Me.LogoutBtn.Text = "Logout"
        Me.LogoutBtn.UseVisualStyleBackColor = True
        '
        'EditProfileBtn
        '
        Me.EditProfileBtn.FlatAppearance.BorderSize = 0
        Me.EditProfileBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.EditProfileBtn.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EditProfileBtn.Location = New System.Drawing.Point(20, 52)
        Me.EditProfileBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.EditProfileBtn.Name = "EditProfileBtn"
        Me.EditProfileBtn.Size = New System.Drawing.Size(311, 50)
        Me.EditProfileBtn.TabIndex = 5
        Me.EditProfileBtn.Text = "Edit Profile"
        Me.EditProfileBtn.UseVisualStyleBackColor = True
        '
        'PersonalInfoPanel2
        '
        Me.PersonalInfoPanel2.BackColor = System.Drawing.Color.Transparent
        Me.PersonalInfoPanel2.Location = New System.Drawing.Point(307, 52)
        Me.PersonalInfoPanel2.Name = "PersonalInfoPanel2"
        Me.PersonalInfoPanel2.Size = New System.Drawing.Size(44, 50)
        Me.PersonalInfoPanel2.TabIndex = 16
        '
        'PersonalInfoPanel1
        '
        Me.PersonalInfoPanel1.BackColor = System.Drawing.Color.Transparent
        Me.PersonalInfoPanel1.Location = New System.Drawing.Point(0, 52)
        Me.PersonalInfoPanel1.Name = "PersonalInfoPanel1"
        Me.PersonalInfoPanel1.Size = New System.Drawing.Size(44, 50)
        Me.PersonalInfoPanel1.TabIndex = 15
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.AvailabilityBtn)
        Me.GroupBox3.Controls.Add(Me.StaffPanel2)
        Me.GroupBox3.Controls.Add(Me.StaffPanel1)
        Me.GroupBox3.Font = New System.Drawing.Font("MS Reference Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(13, 311)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(351, 114)
        Me.GroupBox3.TabIndex = 10
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Staff"
        '
        'AvailabilityBtn
        '
        Me.AvailabilityBtn.FlatAppearance.BorderSize = 0
        Me.AvailabilityBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AvailabilityBtn.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AvailabilityBtn.Location = New System.Drawing.Point(20, 37)
        Me.AvailabilityBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.AvailabilityBtn.Name = "AvailabilityBtn"
        Me.AvailabilityBtn.Size = New System.Drawing.Size(311, 50)
        Me.AvailabilityBtn.TabIndex = 4
        Me.AvailabilityBtn.Text = "Availability"
        Me.AvailabilityBtn.UseVisualStyleBackColor = True
        '
        'StaffPanel2
        '
        Me.StaffPanel2.BackColor = System.Drawing.Color.Transparent
        Me.StaffPanel2.Location = New System.Drawing.Point(307, 37)
        Me.StaffPanel2.Name = "StaffPanel2"
        Me.StaffPanel2.Size = New System.Drawing.Size(44, 50)
        Me.StaffPanel2.TabIndex = 6
        '
        'StaffPanel1
        '
        Me.StaffPanel1.BackColor = System.Drawing.Color.Transparent
        Me.StaffPanel1.Location = New System.Drawing.Point(0, 37)
        Me.StaffPanel1.Name = "StaffPanel1"
        Me.StaffPanel1.Size = New System.Drawing.Size(44, 50)
        Me.StaffPanel1.TabIndex = 5
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.CheckUpBtn)
        Me.GroupBox2.Controls.Add(Me.UpdateDetailsBtn)
        Me.GroupBox2.Controls.Add(Me.AdmitBtn)
        Me.GroupBox2.Controls.Add(Me.RegistrationBtn)
        Me.GroupBox2.Controls.Add(Me.PatientPanel2)
        Me.GroupBox2.Controls.Add(Me.PatientPanel1)
        Me.GroupBox2.Font = New System.Drawing.Font("MS Reference Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(13, 9)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(0)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(351, 267)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Patient"
        '
        'CheckUpBtn
        '
        Me.CheckUpBtn.FlatAppearance.BorderSize = 0
        Me.CheckUpBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.CheckUpBtn.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CheckUpBtn.Location = New System.Drawing.Point(25, 96)
        Me.CheckUpBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.CheckUpBtn.Name = "CheckUpBtn"
        Me.CheckUpBtn.Size = New System.Drawing.Size(306, 50)
        Me.CheckUpBtn.TabIndex = 2
        Me.CheckUpBtn.Text = "Check-Up"
        Me.CheckUpBtn.UseVisualStyleBackColor = True
        '
        'UpdateDetailsBtn
        '
        Me.UpdateDetailsBtn.FlatAppearance.BorderSize = 0
        Me.UpdateDetailsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.UpdateDetailsBtn.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.UpdateDetailsBtn.Location = New System.Drawing.Point(25, 196)
        Me.UpdateDetailsBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.UpdateDetailsBtn.Name = "UpdateDetailsBtn"
        Me.UpdateDetailsBtn.Size = New System.Drawing.Size(306, 50)
        Me.UpdateDetailsBtn.TabIndex = 4
        Me.UpdateDetailsBtn.Text = "Update Details"
        Me.UpdateDetailsBtn.UseVisualStyleBackColor = True
        '
        'AdmitBtn
        '
        Me.AdmitBtn.FlatAppearance.BorderSize = 0
        Me.AdmitBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.AdmitBtn.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AdmitBtn.Location = New System.Drawing.Point(25, 146)
        Me.AdmitBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.AdmitBtn.Name = "AdmitBtn"
        Me.AdmitBtn.Size = New System.Drawing.Size(306, 50)
        Me.AdmitBtn.TabIndex = 3
        Me.AdmitBtn.Text = "Admit/Discharge"
        Me.AdmitBtn.UseVisualStyleBackColor = True
        '
        'RegistrationBtn
        '
        Me.RegistrationBtn.BackColor = System.Drawing.Color.White
        Me.RegistrationBtn.FlatAppearance.BorderSize = 0
        Me.RegistrationBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RegistrationBtn.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegistrationBtn.Location = New System.Drawing.Point(25, 43)
        Me.RegistrationBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.RegistrationBtn.Name = "RegistrationBtn"
        Me.RegistrationBtn.Size = New System.Drawing.Size(306, 50)
        Me.RegistrationBtn.TabIndex = 1
        Me.RegistrationBtn.Text = "Registration"
        Me.RegistrationBtn.UseVisualStyleBackColor = False
        '
        'PatientPanel2
        '
        Me.PatientPanel2.BackColor = System.Drawing.Color.Transparent
        Me.PatientPanel2.Location = New System.Drawing.Point(307, 43)
        Me.PatientPanel2.Name = "PatientPanel2"
        Me.PatientPanel2.Size = New System.Drawing.Size(44, 50)
        Me.PatientPanel2.TabIndex = 6
        '
        'PatientPanel1
        '
        Me.PatientPanel1.BackColor = System.Drawing.Color.Transparent
        Me.PatientPanel1.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PatientPanel1.Location = New System.Drawing.Point(6, 43)
        Me.PatientPanel1.Name = "PatientPanel1"
        Me.PatientPanel1.Size = New System.Drawing.Size(44, 50)
        Me.PatientPanel1.TabIndex = 0
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.BloodAvailabilityBtn)
        Me.GroupBox4.Controls.Add(Me.RegisterRecieverBtn)
        Me.GroupBox4.Controls.Add(Me.RegisterDonorBtn)
        Me.GroupBox4.Controls.Add(Me.BloodBankPanel2)
        Me.GroupBox4.Controls.Add(Me.BloodBankPanel1)
        Me.GroupBox4.Font = New System.Drawing.Font("MS Reference Sans Serif", 16.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(13, 440)
        Me.GroupBox4.Margin = New System.Windows.Forms.Padding(0)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(351, 204)
        Me.GroupBox4.TabIndex = 11
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Blood Bank"
        '
        'BloodAvailabilityBtn
        '
        Me.BloodAvailabilityBtn.FlatAppearance.BorderSize = 0
        Me.BloodAvailabilityBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.BloodAvailabilityBtn.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BloodAvailabilityBtn.Location = New System.Drawing.Point(20, 138)
        Me.BloodAvailabilityBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.BloodAvailabilityBtn.Name = "BloodAvailabilityBtn"
        Me.BloodAvailabilityBtn.Size = New System.Drawing.Size(311, 50)
        Me.BloodAvailabilityBtn.TabIndex = 7
        Me.BloodAvailabilityBtn.Text = "Blood Availability"
        Me.BloodAvailabilityBtn.UseVisualStyleBackColor = True
        '
        'RegisterRecieverBtn
        '
        Me.RegisterRecieverBtn.FlatAppearance.BorderSize = 0
        Me.RegisterRecieverBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RegisterRecieverBtn.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegisterRecieverBtn.Location = New System.Drawing.Point(20, 88)
        Me.RegisterRecieverBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.RegisterRecieverBtn.Name = "RegisterRecieverBtn"
        Me.RegisterRecieverBtn.Size = New System.Drawing.Size(311, 50)
        Me.RegisterRecieverBtn.TabIndex = 6
        Me.RegisterRecieverBtn.Text = "Register Reciever"
        Me.RegisterRecieverBtn.UseVisualStyleBackColor = True
        '
        'RegisterDonorBtn
        '
        Me.RegisterDonorBtn.FlatAppearance.BorderSize = 0
        Me.RegisterDonorBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.RegisterDonorBtn.Font = New System.Drawing.Font("MS Reference Sans Serif", 10.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.RegisterDonorBtn.Location = New System.Drawing.Point(20, 38)
        Me.RegisterDonorBtn.Margin = New System.Windows.Forms.Padding(0)
        Me.RegisterDonorBtn.Name = "RegisterDonorBtn"
        Me.RegisterDonorBtn.Size = New System.Drawing.Size(311, 50)
        Me.RegisterDonorBtn.TabIndex = 5
        Me.RegisterDonorBtn.Text = "Register Donor"
        Me.RegisterDonorBtn.UseVisualStyleBackColor = True
        '
        'BloodBankPanel2
        '
        Me.BloodBankPanel2.BackColor = System.Drawing.Color.Transparent
        Me.BloodBankPanel2.Location = New System.Drawing.Point(307, 38)
        Me.BloodBankPanel2.Name = "BloodBankPanel2"
        Me.BloodBankPanel2.Size = New System.Drawing.Size(44, 50)
        Me.BloodBankPanel2.TabIndex = 15
        '
        'BloodBankPanel1
        '
        Me.BloodBankPanel1.BackColor = System.Drawing.Color.Transparent
        Me.BloodBankPanel1.Location = New System.Drawing.Point(0, 38)
        Me.BloodBankPanel1.Name = "BloodBankPanel1"
        Me.BloodBankPanel1.Size = New System.Drawing.Size(44, 50)
        Me.BloodBankPanel1.TabIndex = 14
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Hospital_Management_System.My.Resources.Resources.Hospital_blue_icon
        Me.PictureBox1.Location = New System.Drawing.Point(307, 12)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(106, 103)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 7
        Me.PictureBox1.TabStop = False
        '
        'Form2
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.MidnightBlue
        Me.ClientSize = New System.Drawing.Size(1285, 973)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.StaffPanel)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form2"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show
        Me.Text = "Form2"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Panel1.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents StaffPanel As System.Windows.Forms.Panel
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox5 As System.Windows.Forms.GroupBox
    Friend WithEvents LogoutBtn As System.Windows.Forms.Button
    Friend WithEvents EditProfileBtn As System.Windows.Forms.Button
    Friend WithEvents PersonalInfoPanel2 As System.Windows.Forms.Panel
    Friend WithEvents PersonalInfoPanel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents AvailabilityBtn As System.Windows.Forms.Button
    Friend WithEvents StaffPanel2 As System.Windows.Forms.Panel
    Friend WithEvents StaffPanel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents CheckUpBtn As System.Windows.Forms.Button
    Friend WithEvents UpdateDetailsBtn As System.Windows.Forms.Button
    Friend WithEvents AdmitBtn As System.Windows.Forms.Button
    Friend WithEvents RegistrationBtn As System.Windows.Forms.Button
    Friend WithEvents PatientPanel2 As System.Windows.Forms.Panel
    Friend WithEvents PatientPanel1 As System.Windows.Forms.Panel
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents BloodAvailabilityBtn As System.Windows.Forms.Button
    Friend WithEvents RegisterRecieverBtn As System.Windows.Forms.Button
    Friend WithEvents RegisterDonorBtn As System.Windows.Forms.Button
    Friend WithEvents BloodBankPanel2 As System.Windows.Forms.Panel
    Friend WithEvents BloodBankPanel1 As System.Windows.Forms.Panel
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
