﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button5 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.tabRegistration = New System.Windows.Forms.TabPage()
        Me.btnRCLEAR = New System.Windows.Forms.Button()
        Me.btnRADD = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtRAddress = New System.Windows.Forms.TextBox()
        Me.txtRMobile = New System.Windows.Forms.TextBox()
        Me.txtRGender = New System.Windows.Forms.TextBox()
        Me.txtRAge = New System.Windows.Forms.TextBox()
        Me.txtRName = New System.Windows.Forms.TextBox()
        Me.tabConsultation = New System.Windows.Forms.TabPage()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtCFee = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.txtCTokenNo = New System.Windows.Forms.TextBox()
        Me.txtCRoomNo = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.txtCPID = New System.Windows.Forms.TextBox()
        Me.btnCCLEAR = New System.Windows.Forms.Button()
        Me.btnCPRINT = New System.Windows.Forms.Button()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.txtCAddress = New System.Windows.Forms.TextBox()
        Me.txtCMobile = New System.Windows.Forms.TextBox()
        Me.txtCGender = New System.Windows.Forms.TextBox()
        Me.txtCAge = New System.Windows.Forms.TextBox()
        Me.txtCName = New System.Windows.Forms.TextBox()
        Me.btnCSEARCH = New System.Windows.Forms.Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.DataGridViewC = New System.Windows.Forms.DataGridView()
        Me.txtCSMobile = New System.Windows.Forms.TextBox()
        Me.tabAdmit = New System.Windows.Forms.TabPage()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.txtADateOut = New System.Windows.Forms.TextBox()
        Me.txtAFee = New System.Windows.Forms.TextBox()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.txtADisease = New System.Windows.Forms.TextBox()
        Me.txtAStatus = New System.Windows.Forms.TextBox()
        Me.txtADateIn = New System.Windows.Forms.TextBox()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.txtARoomType = New System.Windows.Forms.TextBox()
        Me.txtARoomNo = New System.Windows.Forms.TextBox()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtAPID = New System.Windows.Forms.TextBox()
        Me.btnACLEAR = New System.Windows.Forms.Button()
        Me.btnAPRINT = New System.Windows.Forms.Button()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.txtAAddress = New System.Windows.Forms.TextBox()
        Me.txtAMobile = New System.Windows.Forms.TextBox()
        Me.txtAGender = New System.Windows.Forms.TextBox()
        Me.txtAAge = New System.Windows.Forms.TextBox()
        Me.txtAName = New System.Windows.Forms.TextBox()
        Me.btnASEARCH = New System.Windows.Forms.Button()
        Me.DataGridViewA = New System.Windows.Forms.DataGridView()
        Me.txtASMobile = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.btnAFEE = New System.Windows.Forms.Button()
        Me.btnAUPDATE = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.TabControl1.SuspendLayout()
        Me.tabRegistration.SuspendLayout()
        Me.tabConsultation.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.DataGridViewC, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.tabAdmit.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        CType(Me.DataGridViewA, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button5)
        Me.GroupBox1.Controls.Add(Me.Button4)
        Me.GroupBox1.Controls.Add(Me.Button3)
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(251, 629)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "MENU"
        '
        'Button5
        '
        Me.Button5.Location = New System.Drawing.Point(22, 558)
        Me.Button5.Name = "Button5"
        Me.Button5.Size = New System.Drawing.Size(206, 50)
        Me.Button5.TabIndex = 4
        Me.Button5.Text = "Logout"
        Me.Button5.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(0, 229)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(251, 45)
        Me.Button4.TabIndex = 3
        Me.Button4.Text = "Button4"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(0, 170)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(251, 44)
        Me.Button3.TabIndex = 2
        Me.Button3.Text = "Admit Form / Report"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(0, 111)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(251, 44)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "Doctor Consultation"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(0, 55)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(251, 45)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Patient Registration"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.tabRegistration)
        Me.TabControl1.Controls.Add(Me.tabConsultation)
        Me.TabControl1.Controls.Add(Me.tabAdmit)
        Me.TabControl1.Controls.Add(Me.TabPage4)
        Me.TabControl1.Location = New System.Drawing.Point(280, 12)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(1010, 629)
        Me.TabControl1.TabIndex = 1
        '
        'tabRegistration
        '
        Me.tabRegistration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.tabRegistration.Controls.Add(Me.btnRCLEAR)
        Me.tabRegistration.Controls.Add(Me.btnRADD)
        Me.tabRegistration.Controls.Add(Me.Label5)
        Me.tabRegistration.Controls.Add(Me.Label4)
        Me.tabRegistration.Controls.Add(Me.Label3)
        Me.tabRegistration.Controls.Add(Me.Label2)
        Me.tabRegistration.Controls.Add(Me.Label1)
        Me.tabRegistration.Controls.Add(Me.txtRAddress)
        Me.tabRegistration.Controls.Add(Me.txtRMobile)
        Me.tabRegistration.Controls.Add(Me.txtRGender)
        Me.tabRegistration.Controls.Add(Me.txtRAge)
        Me.tabRegistration.Controls.Add(Me.txtRName)
        Me.tabRegistration.Location = New System.Drawing.Point(4, 29)
        Me.tabRegistration.Name = "tabRegistration"
        Me.tabRegistration.Padding = New System.Windows.Forms.Padding(3)
        Me.tabRegistration.Size = New System.Drawing.Size(1002, 596)
        Me.tabRegistration.TabIndex = 0
        Me.tabRegistration.Text = "Registration"
        Me.tabRegistration.UseVisualStyleBackColor = True
        '
        'btnRCLEAR
        '
        Me.btnRCLEAR.Location = New System.Drawing.Point(817, 493)
        Me.btnRCLEAR.Name = "btnRCLEAR"
        Me.btnRCLEAR.Size = New System.Drawing.Size(139, 52)
        Me.btnRCLEAR.TabIndex = 19
        Me.btnRCLEAR.Text = "CLEAR"
        Me.btnRCLEAR.UseVisualStyleBackColor = True
        '
        'btnRADD
        '
        Me.btnRADD.Location = New System.Drawing.Point(623, 492)
        Me.btnRADD.Name = "btnRADD"
        Me.btnRADD.Size = New System.Drawing.Size(146, 53)
        Me.btnRADD.TabIndex = 17
        Me.btnRADD.Text = "ADD"
        Me.btnRADD.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(141, 357)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(68, 20)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Address"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(141, 298)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 20)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Mobile"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(141, 234)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 20)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Gender"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(141, 172)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 20)
        Me.Label2.TabIndex = 13
        Me.Label2.Text = "Age"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(141, 108)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(51, 20)
        Me.Label1.TabIndex = 12
        Me.Label1.Text = "Name"
        '
        'txtRAddress
        '
        Me.txtRAddress.Location = New System.Drawing.Point(342, 354)
        Me.txtRAddress.Multiline = True
        Me.txtRAddress.Name = "txtRAddress"
        Me.txtRAddress.Size = New System.Drawing.Size(223, 86)
        Me.txtRAddress.TabIndex = 11
        '
        'txtRMobile
        '
        Me.txtRMobile.Location = New System.Drawing.Point(342, 292)
        Me.txtRMobile.Name = "txtRMobile"
        Me.txtRMobile.Size = New System.Drawing.Size(223, 26)
        Me.txtRMobile.TabIndex = 10
        '
        'txtRGender
        '
        Me.txtRGender.Location = New System.Drawing.Point(342, 228)
        Me.txtRGender.Name = "txtRGender"
        Me.txtRGender.Size = New System.Drawing.Size(223, 26)
        Me.txtRGender.TabIndex = 9
        '
        'txtRAge
        '
        Me.txtRAge.Location = New System.Drawing.Point(342, 166)
        Me.txtRAge.Name = "txtRAge"
        Me.txtRAge.Size = New System.Drawing.Size(223, 26)
        Me.txtRAge.TabIndex = 8
        '
        'txtRName
        '
        Me.txtRName.Location = New System.Drawing.Point(342, 102)
        Me.txtRName.Name = "txtRName"
        Me.txtRName.Size = New System.Drawing.Size(223, 26)
        Me.txtRName.TabIndex = 7
        '
        'tabConsultation
        '
        Me.tabConsultation.Controls.Add(Me.GroupBox2)
        Me.tabConsultation.Controls.Add(Me.btnCSEARCH)
        Me.tabConsultation.Controls.Add(Me.Label6)
        Me.tabConsultation.Controls.Add(Me.DataGridViewC)
        Me.tabConsultation.Controls.Add(Me.txtCSMobile)
        Me.tabConsultation.Location = New System.Drawing.Point(4, 29)
        Me.tabConsultation.Name = "tabConsultation"
        Me.tabConsultation.Padding = New System.Windows.Forms.Padding(3)
        Me.tabConsultation.Size = New System.Drawing.Size(1002, 596)
        Me.tabConsultation.TabIndex = 1
        Me.tabConsultation.Text = "Consultation"
        Me.tabConsultation.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Label15)
        Me.GroupBox2.Controls.Add(Me.txtCFee)
        Me.GroupBox2.Controls.Add(Me.Label14)
        Me.GroupBox2.Controls.Add(Me.Label13)
        Me.GroupBox2.Controls.Add(Me.txtCTokenNo)
        Me.GroupBox2.Controls.Add(Me.txtCRoomNo)
        Me.GroupBox2.Controls.Add(Me.Label12)
        Me.GroupBox2.Controls.Add(Me.txtCPID)
        Me.GroupBox2.Controls.Add(Me.btnCCLEAR)
        Me.GroupBox2.Controls.Add(Me.btnCPRINT)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.Label11)
        Me.GroupBox2.Controls.Add(Me.txtCAddress)
        Me.GroupBox2.Controls.Add(Me.txtCMobile)
        Me.GroupBox2.Controls.Add(Me.txtCGender)
        Me.GroupBox2.Controls.Add(Me.txtCAge)
        Me.GroupBox2.Controls.Add(Me.txtCName)
        Me.GroupBox2.Location = New System.Drawing.Point(11, 237)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(985, 353)
        Me.GroupBox2.TabIndex = 15
        Me.GroupBox2.TabStop = False
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Location = New System.Drawing.Point(585, 185)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(37, 20)
        Me.Label15.TabIndex = 21
        Me.Label15.Text = "Fee"
        '
        'txtCFee
        '
        Me.txtCFee.Location = New System.Drawing.Point(761, 179)
        Me.txtCFee.Name = "txtCFee"
        Me.txtCFee.ReadOnly = True
        Me.txtCFee.Size = New System.Drawing.Size(164, 26)
        Me.txtCFee.TabIndex = 20
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Location = New System.Drawing.Point(585, 138)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(81, 20)
        Me.Label14.TabIndex = 19
        Me.Label14.Text = "Token No."
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(585, 89)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(80, 20)
        Me.Label13.TabIndex = 18
        Me.Label13.Text = "Room No."
        '
        'txtCTokenNo
        '
        Me.txtCTokenNo.Location = New System.Drawing.Point(761, 132)
        Me.txtCTokenNo.Name = "txtCTokenNo"
        Me.txtCTokenNo.Size = New System.Drawing.Size(165, 26)
        Me.txtCTokenNo.TabIndex = 17
        '
        'txtCRoomNo
        '
        Me.txtCRoomNo.Location = New System.Drawing.Point(761, 83)
        Me.txtCRoomNo.Name = "txtCRoomNo"
        Me.txtCRoomNo.Size = New System.Drawing.Size(165, 26)
        Me.txtCRoomNo.TabIndex = 16
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(44, 44)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 20)
        Me.Label12.TabIndex = 15
        Me.Label12.Text = "PID"
        '
        'txtCPID
        '
        Me.txtCPID.Location = New System.Drawing.Point(218, 38)
        Me.txtCPID.Name = "txtCPID"
        Me.txtCPID.ReadOnly = True
        Me.txtCPID.Size = New System.Drawing.Size(165, 26)
        Me.txtCPID.TabIndex = 14
        '
        'btnCCLEAR
        '
        Me.btnCCLEAR.Location = New System.Drawing.Point(761, 244)
        Me.btnCCLEAR.Name = "btnCCLEAR"
        Me.btnCCLEAR.Size = New System.Drawing.Size(165, 48)
        Me.btnCCLEAR.TabIndex = 13
        Me.btnCCLEAR.Text = "CLEAR"
        Me.btnCCLEAR.UseVisualStyleBackColor = True
        '
        'btnCPRINT
        '
        Me.btnCPRINT.Location = New System.Drawing.Point(542, 243)
        Me.btnCPRINT.Name = "btnCPRINT"
        Me.btnCPRINT.Size = New System.Drawing.Size(163, 49)
        Me.btnCPRINT.TabIndex = 12
        Me.btnCPRINT.Text = "PRINT"
        Me.btnCPRINT.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(44, 272)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(68, 20)
        Me.Label7.TabIndex = 11
        Me.Label7.Text = "Address"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(44, 229)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(55, 20)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Mobile"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(44, 182)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(63, 20)
        Me.Label9.TabIndex = 9
        Me.Label9.Text = "Gender"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(44, 135)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(38, 20)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Age"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(44, 89)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(51, 20)
        Me.Label11.TabIndex = 7
        Me.Label11.Text = "Name"
        '
        'txtCAddress
        '
        Me.txtCAddress.Location = New System.Drawing.Point(218, 269)
        Me.txtCAddress.Multiline = True
        Me.txtCAddress.Name = "txtCAddress"
        Me.txtCAddress.ReadOnly = True
        Me.txtCAddress.Size = New System.Drawing.Size(165, 75)
        Me.txtCAddress.TabIndex = 5
        '
        'txtCMobile
        '
        Me.txtCMobile.Location = New System.Drawing.Point(218, 223)
        Me.txtCMobile.Name = "txtCMobile"
        Me.txtCMobile.ReadOnly = True
        Me.txtCMobile.Size = New System.Drawing.Size(165, 26)
        Me.txtCMobile.TabIndex = 4
        '
        'txtCGender
        '
        Me.txtCGender.Location = New System.Drawing.Point(218, 176)
        Me.txtCGender.Name = "txtCGender"
        Me.txtCGender.ReadOnly = True
        Me.txtCGender.Size = New System.Drawing.Size(165, 26)
        Me.txtCGender.TabIndex = 3
        '
        'txtCAge
        '
        Me.txtCAge.Location = New System.Drawing.Point(218, 129)
        Me.txtCAge.Name = "txtCAge"
        Me.txtCAge.ReadOnly = True
        Me.txtCAge.Size = New System.Drawing.Size(165, 26)
        Me.txtCAge.TabIndex = 2
        '
        'txtCName
        '
        Me.txtCName.Location = New System.Drawing.Point(218, 83)
        Me.txtCName.Name = "txtCName"
        Me.txtCName.ReadOnly = True
        Me.txtCName.Size = New System.Drawing.Size(165, 26)
        Me.txtCName.TabIndex = 1
        '
        'btnCSEARCH
        '
        Me.btnCSEARCH.Location = New System.Drawing.Point(852, 15)
        Me.btnCSEARCH.Name = "btnCSEARCH"
        Me.btnCSEARCH.Size = New System.Drawing.Size(144, 36)
        Me.btnCSEARCH.TabIndex = 3
        Me.btnCSEARCH.Text = "SEARCH"
        Me.btnCSEARCH.UseVisualStyleBackColor = True
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(6, 26)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(76, 25)
        Me.Label6.TabIndex = 2
        Me.Label6.Text = "Mobile:"
        '
        'DataGridViewC
        '
        Me.DataGridViewC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewC.Location = New System.Drawing.Point(6, 68)
        Me.DataGridViewC.Name = "DataGridViewC"
        Me.DataGridViewC.RowTemplate.Height = 28
        Me.DataGridViewC.Size = New System.Drawing.Size(990, 149)
        Me.DataGridViewC.TabIndex = 1
        '
        'txtCSMobile
        '
        Me.txtCSMobile.Location = New System.Drawing.Point(88, 25)
        Me.txtCSMobile.Name = "txtCSMobile"
        Me.txtCSMobile.Size = New System.Drawing.Size(181, 26)
        Me.txtCSMobile.TabIndex = 0
        '
        'tabAdmit
        '
        Me.tabAdmit.Controls.Add(Me.GroupBox3)
        Me.tabAdmit.Controls.Add(Me.btnASEARCH)
        Me.tabAdmit.Controls.Add(Me.DataGridViewA)
        Me.tabAdmit.Controls.Add(Me.txtASMobile)
        Me.tabAdmit.Controls.Add(Me.Label16)
        Me.tabAdmit.Location = New System.Drawing.Point(4, 29)
        Me.tabAdmit.Name = "tabAdmit"
        Me.tabAdmit.Size = New System.Drawing.Size(1002, 596)
        Me.tabAdmit.TabIndex = 2
        Me.tabAdmit.Text = "Admit"
        Me.tabAdmit.UseVisualStyleBackColor = True
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnAUPDATE)
        Me.GroupBox3.Controls.Add(Me.btnAFEE)
        Me.GroupBox3.Controls.Add(Me.Label29)
        Me.GroupBox3.Controls.Add(Me.Label28)
        Me.GroupBox3.Controls.Add(Me.txtADateOut)
        Me.GroupBox3.Controls.Add(Me.txtAFee)
        Me.GroupBox3.Controls.Add(Me.Label27)
        Me.GroupBox3.Controls.Add(Me.Label26)
        Me.GroupBox3.Controls.Add(Me.txtADisease)
        Me.GroupBox3.Controls.Add(Me.txtAStatus)
        Me.GroupBox3.Controls.Add(Me.txtADateIn)
        Me.GroupBox3.Controls.Add(Me.Label18)
        Me.GroupBox3.Controls.Add(Me.Label19)
        Me.GroupBox3.Controls.Add(Me.txtARoomType)
        Me.GroupBox3.Controls.Add(Me.txtARoomNo)
        Me.GroupBox3.Controls.Add(Me.Label20)
        Me.GroupBox3.Controls.Add(Me.txtAPID)
        Me.GroupBox3.Controls.Add(Me.btnACLEAR)
        Me.GroupBox3.Controls.Add(Me.btnAPRINT)
        Me.GroupBox3.Controls.Add(Me.Label21)
        Me.GroupBox3.Controls.Add(Me.Label22)
        Me.GroupBox3.Controls.Add(Me.Label23)
        Me.GroupBox3.Controls.Add(Me.Label24)
        Me.GroupBox3.Controls.Add(Me.Label25)
        Me.GroupBox3.Controls.Add(Me.txtAAddress)
        Me.GroupBox3.Controls.Add(Me.txtAMobile)
        Me.GroupBox3.Controls.Add(Me.txtAGender)
        Me.GroupBox3.Controls.Add(Me.txtAAge)
        Me.GroupBox3.Controls.Add(Me.txtAName)
        Me.GroupBox3.Location = New System.Drawing.Point(8, 212)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(985, 381)
        Me.GroupBox3.TabIndex = 16
        Me.GroupBox3.TabStop = False
        '
        'txtADateOut
        '
        Me.txtADateOut.Location = New System.Drawing.Point(671, 266)
        Me.txtADateOut.Name = "txtADateOut"
        Me.txtADateOut.Size = New System.Drawing.Size(164, 26)
        Me.txtADateOut.TabIndex = 27
        '
        'txtAFee
        '
        Me.txtAFee.Location = New System.Drawing.Point(671, 317)
        Me.txtAFee.Name = "txtAFee"
        Me.txtAFee.ReadOnly = True
        Me.txtAFee.Size = New System.Drawing.Size(164, 26)
        Me.txtAFee.TabIndex = 26
        '
        'Label27
        '
        Me.Label27.AutoSize = True
        Me.Label27.Location = New System.Drawing.Point(486, 89)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(136, 20)
        Me.Label27.TabIndex = 25
        Me.Label27.Text = "Status of Disease"
        '
        'Label26
        '
        Me.Label26.AutoSize = True
        Me.Label26.Location = New System.Drawing.Point(484, 44)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(67, 20)
        Me.Label26.TabIndex = 24
        Me.Label26.Text = "Disease"
        '
        'txtADisease
        '
        Me.txtADisease.Location = New System.Drawing.Point(670, 38)
        Me.txtADisease.Name = "txtADisease"
        Me.txtADisease.Size = New System.Drawing.Size(165, 26)
        Me.txtADisease.TabIndex = 23
        '
        'txtAStatus
        '
        Me.txtAStatus.Location = New System.Drawing.Point(670, 83)
        Me.txtAStatus.Name = "txtAStatus"
        Me.txtAStatus.Size = New System.Drawing.Size(165, 26)
        Me.txtAStatus.TabIndex = 22
        '
        'txtADateIn
        '
        Me.txtADateIn.Location = New System.Drawing.Point(671, 217)
        Me.txtADateIn.Name = "txtADateIn"
        Me.txtADateIn.Size = New System.Drawing.Size(164, 26)
        Me.txtADateIn.TabIndex = 20
        '
        'Label18
        '
        Me.Label18.AutoSize = True
        Me.Label18.Location = New System.Drawing.Point(486, 179)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(90, 20)
        Me.Label18.TabIndex = 19
        Me.Label18.Text = "Room Type"
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(486, 132)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(80, 20)
        Me.Label19.TabIndex = 18
        Me.Label19.Text = "Room No."
        '
        'txtARoomType
        '
        Me.txtARoomType.Location = New System.Drawing.Point(670, 173)
        Me.txtARoomType.Name = "txtARoomType"
        Me.txtARoomType.Size = New System.Drawing.Size(165, 26)
        Me.txtARoomType.TabIndex = 17
        '
        'txtARoomNo
        '
        Me.txtARoomNo.Location = New System.Drawing.Point(670, 126)
        Me.txtARoomNo.Name = "txtARoomNo"
        Me.txtARoomNo.Size = New System.Drawing.Size(165, 26)
        Me.txtARoomNo.TabIndex = 16
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(44, 44)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(36, 20)
        Me.Label20.TabIndex = 15
        Me.Label20.Text = "PID"
        '
        'txtAPID
        '
        Me.txtAPID.Location = New System.Drawing.Point(218, 38)
        Me.txtAPID.Name = "txtAPID"
        Me.txtAPID.ReadOnly = True
        Me.txtAPID.Size = New System.Drawing.Size(165, 26)
        Me.txtAPID.TabIndex = 14
        '
        'btnACLEAR
        '
        Me.btnACLEAR.Location = New System.Drawing.Point(858, 154)
        Me.btnACLEAR.Name = "btnACLEAR"
        Me.btnACLEAR.Size = New System.Drawing.Size(121, 65)
        Me.btnACLEAR.TabIndex = 13
        Me.btnACLEAR.Text = "CLEAR"
        Me.btnACLEAR.UseVisualStyleBackColor = True
        '
        'btnAPRINT
        '
        Me.btnAPRINT.Location = New System.Drawing.Point(858, 266)
        Me.btnAPRINT.Name = "btnAPRINT"
        Me.btnAPRINT.Size = New System.Drawing.Size(121, 73)
        Me.btnAPRINT.TabIndex = 12
        Me.btnAPRINT.Text = "PRINT"
        Me.btnAPRINT.UseVisualStyleBackColor = True
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(44, 272)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(68, 20)
        Me.Label21.TabIndex = 11
        Me.Label21.Text = "Address"
        '
        'Label22
        '
        Me.Label22.AutoSize = True
        Me.Label22.Location = New System.Drawing.Point(44, 229)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(55, 20)
        Me.Label22.TabIndex = 10
        Me.Label22.Text = "Mobile"
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Location = New System.Drawing.Point(44, 182)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(63, 20)
        Me.Label23.TabIndex = 9
        Me.Label23.Text = "Gender"
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Location = New System.Drawing.Point(44, 135)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(38, 20)
        Me.Label24.TabIndex = 8
        Me.Label24.Text = "Age"
        '
        'Label25
        '
        Me.Label25.AutoSize = True
        Me.Label25.Location = New System.Drawing.Point(44, 89)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(51, 20)
        Me.Label25.TabIndex = 7
        Me.Label25.Text = "Name"
        '
        'txtAAddress
        '
        Me.txtAAddress.Location = New System.Drawing.Point(218, 269)
        Me.txtAAddress.Multiline = True
        Me.txtAAddress.Name = "txtAAddress"
        Me.txtAAddress.Size = New System.Drawing.Size(165, 75)
        Me.txtAAddress.TabIndex = 5
        '
        'txtAMobile
        '
        Me.txtAMobile.Location = New System.Drawing.Point(218, 223)
        Me.txtAMobile.Name = "txtAMobile"
        Me.txtAMobile.Size = New System.Drawing.Size(165, 26)
        Me.txtAMobile.TabIndex = 4
        '
        'txtAGender
        '
        Me.txtAGender.Location = New System.Drawing.Point(218, 176)
        Me.txtAGender.Name = "txtAGender"
        Me.txtAGender.Size = New System.Drawing.Size(165, 26)
        Me.txtAGender.TabIndex = 3
        '
        'txtAAge
        '
        Me.txtAAge.Location = New System.Drawing.Point(218, 129)
        Me.txtAAge.Name = "txtAAge"
        Me.txtAAge.Size = New System.Drawing.Size(165, 26)
        Me.txtAAge.TabIndex = 2
        '
        'txtAName
        '
        Me.txtAName.Location = New System.Drawing.Point(218, 83)
        Me.txtAName.Name = "txtAName"
        Me.txtAName.Size = New System.Drawing.Size(165, 26)
        Me.txtAName.TabIndex = 1
        '
        'btnASEARCH
        '
        Me.btnASEARCH.Location = New System.Drawing.Point(849, 11)
        Me.btnASEARCH.Name = "btnASEARCH"
        Me.btnASEARCH.Size = New System.Drawing.Size(144, 36)
        Me.btnASEARCH.TabIndex = 6
        Me.btnASEARCH.Text = "SEARCH"
        Me.btnASEARCH.UseVisualStyleBackColor = True
        '
        'DataGridViewA
        '
        Me.DataGridViewA.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridViewA.Location = New System.Drawing.Point(3, 57)
        Me.DataGridViewA.Name = "DataGridViewA"
        Me.DataGridViewA.RowTemplate.Height = 28
        Me.DataGridViewA.Size = New System.Drawing.Size(990, 149)
        Me.DataGridViewA.TabIndex = 5
        '
        'txtASMobile
        '
        Me.txtASMobile.Location = New System.Drawing.Point(112, 16)
        Me.txtASMobile.Name = "txtASMobile"
        Me.txtASMobile.Size = New System.Drawing.Size(181, 26)
        Me.txtASMobile.TabIndex = 4
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(3, 17)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(76, 25)
        Me.Label16.TabIndex = 3
        Me.Label16.Text = "Mobile:"
        '
        'TabPage4
        '
        Me.TabPage4.Location = New System.Drawing.Point(4, 29)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Size = New System.Drawing.Size(1002, 596)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "TabPage4"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'Label28
        '
        Me.Label28.AutoSize = True
        Me.Label28.Location = New System.Drawing.Point(486, 223)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(64, 20)
        Me.Label28.TabIndex = 28
        Me.Label28.Text = "Date IN"
        '
        'Label29
        '
        Me.Label29.AutoSize = True
        Me.Label29.Location = New System.Drawing.Point(486, 269)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(81, 20)
        Me.Label29.TabIndex = 29
        Me.Label29.Text = "Date OUT"
        '
        'btnAFEE
        '
        Me.btnAFEE.Location = New System.Drawing.Point(479, 312)
        Me.btnAFEE.Name = "btnAFEE"
        Me.btnAFEE.Size = New System.Drawing.Size(134, 36)
        Me.btnAFEE.TabIndex = 30
        Me.btnAFEE.Text = "FEE"
        Me.btnAFEE.UseVisualStyleBackColor = True
        '
        'btnAUPDATE
        '
        Me.btnAUPDATE.Location = New System.Drawing.Point(858, 38)
        Me.btnAUPDATE.Name = "btnAUPDATE"
        Me.btnAUPDATE.Size = New System.Drawing.Size(121, 65)
        Me.btnAUPDATE.TabIndex = 31
        Me.btnAUPDATE.Text = "UPDATE"
        Me.btnAUPDATE.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1302, 653)
        Me.Controls.Add(Me.TabControl1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.TabControl1.ResumeLayout(False)
        Me.tabRegistration.ResumeLayout(False)
        Me.tabRegistration.PerformLayout()
        Me.tabConsultation.ResumeLayout(False)
        Me.tabConsultation.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.DataGridViewC, System.ComponentModel.ISupportInitialize).EndInit()
        Me.tabAdmit.ResumeLayout(False)
        Me.tabAdmit.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        CType(Me.DataGridViewA, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents tabRegistration As System.Windows.Forms.TabPage
    Friend WithEvents tabConsultation As System.Windows.Forms.TabPage
    Friend WithEvents tabAdmit As System.Windows.Forms.TabPage
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents txtRName As System.Windows.Forms.TextBox
    Friend WithEvents txtRAge As System.Windows.Forms.TextBox
    Friend WithEvents txtRGender As System.Windows.Forms.TextBox
    Friend WithEvents txtRMobile As System.Windows.Forms.TextBox
    Friend WithEvents txtRAddress As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnRADD As System.Windows.Forms.Button
    Friend WithEvents btnRCLEAR As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button5 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents DataGridViewC As System.Windows.Forms.DataGridView
    Friend WithEvents txtCSMobile As System.Windows.Forms.TextBox
    Friend WithEvents btnCSEARCH As System.Windows.Forms.Button
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCPID As System.Windows.Forms.TextBox
    Friend WithEvents btnCCLEAR As System.Windows.Forms.Button
    Friend WithEvents btnCPRINT As System.Windows.Forms.Button
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents txtCAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtCMobile As System.Windows.Forms.TextBox
    Friend WithEvents txtCGender As System.Windows.Forms.TextBox
    Friend WithEvents txtCAge As System.Windows.Forms.TextBox
    Friend WithEvents txtCName As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents txtCTokenNo As System.Windows.Forms.TextBox
    Friend WithEvents txtCRoomNo As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtCFee As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents txtADateIn As System.Windows.Forms.TextBox
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents txtARoomType As System.Windows.Forms.TextBox
    Friend WithEvents txtARoomNo As System.Windows.Forms.TextBox
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtAPID As System.Windows.Forms.TextBox
    Friend WithEvents btnACLEAR As System.Windows.Forms.Button
    Friend WithEvents btnAPRINT As System.Windows.Forms.Button
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents txtAAddress As System.Windows.Forms.TextBox
    Friend WithEvents txtAMobile As System.Windows.Forms.TextBox
    Friend WithEvents txtAGender As System.Windows.Forms.TextBox
    Friend WithEvents txtAAge As System.Windows.Forms.TextBox
    Friend WithEvents txtAName As System.Windows.Forms.TextBox
    Friend WithEvents btnASEARCH As System.Windows.Forms.Button
    Friend WithEvents DataGridViewA As System.Windows.Forms.DataGridView
    Friend WithEvents txtASMobile As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents txtADisease As System.Windows.Forms.TextBox
    Friend WithEvents txtAStatus As System.Windows.Forms.TextBox
    Friend WithEvents txtADateOut As System.Windows.Forms.TextBox
    Friend WithEvents txtAFee As System.Windows.Forms.TextBox
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents btnAUPDATE As System.Windows.Forms.Button
    Friend WithEvents btnAFEE As System.Windows.Forms.Button

End Class
